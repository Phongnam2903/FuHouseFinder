#!/bin/bash

mvn versions:commit