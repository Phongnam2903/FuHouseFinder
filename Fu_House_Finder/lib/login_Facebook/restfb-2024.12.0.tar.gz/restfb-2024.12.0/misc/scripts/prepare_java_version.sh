#!/bin/bash

mvn versions:set -DnewVersion=$CZ_PRE_NEW_VERSION